import { Component } from '@angular/core';
import {ContactListComponent} from'./contactList.component'
@Component({
  selector: 'home1',
  template:`
<h1>howwn</h1>
`,

})
export class HomeComponent1  { 




}
