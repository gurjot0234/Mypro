import { Component } from '@angular/core';
import {ContactListComponent} from'./contactList.component'
@Component({
  selector: 'my',
  template:`
<contactlist></contactlist>
`,

})
export class HomeComponent  { 




}
