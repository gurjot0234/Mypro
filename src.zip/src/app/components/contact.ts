export interface contact{
firstName:string,
last:string,
phone:string,
email:string

}