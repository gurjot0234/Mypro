import{contact} from'./contact'
export const CONTACTS:contact[]=[
{firstName:"Max",last:"bond",phone:"998863",email:"a@b.com"},
{firstName:"Max1",last:"bond2",phone:"998863",email:"a@b.com"},
{firstName:"M3",last:"bond3",phone:"998863",email:"a@b.com"}
]